from angr import Project, SimProcedure
import claripy

class MyStrlen(SimProcedure):
	def run(self, reutrn_values=None):
		return 24

class MyGetenv(SimProcedure):
	def run(self, return_values=None):
		return 0x7fffffffe947

class MyStrncpy(SimProcedure):
	def run(self, return_values=None):
		return

env_var = {"hel1oworld": "a"*24}
project = Project("./helloworld", load_options={"auto_load_libs": False})
project.hook_symbol('strlen', MyStrlen())
project.hook_symbol('getenv', MyGetenv())
project.hook_symbol('strncpy', MyStrncpy())
s = project.factory.entry_state(args=["./helloworld"], env=env_var)
ans = s.solver.BVS("ans", 8*24)
s.memory.store(0x7fffffffe947, ans)
s.memory.store(0x60c750, ans)

sm = project.factory.simulation_manager(s, immutable=False)
sm.explore(find=0x40c1ab)

found_state = sm.found[0]
found_state.solver.eval(ans, cast_to=str).strip('\0')
