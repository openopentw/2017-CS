#!/bin/sh
sleep 1
for i in {1..250}
do 
	xdotool key 1 KP_Enter
	sleep 0.3
	xdotool key Up Up KP_Enter c KP_Enter
	sleep 0.3
	xdotool key 2 KP_Enter
	sleep 0.3
done
